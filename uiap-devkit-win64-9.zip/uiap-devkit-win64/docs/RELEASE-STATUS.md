# Release Status

- Version: `0.4.1-test9`
- Build date: `2026-07-25`
- Platform: Windows 11 x64
- Runtime: Windows native, MSYS2 not used
- Distribution: Online bootstrap prototype

## Windows実機で確認済みの基礎

- xPackベースの起動とセットアップ
- UIAPduino V1.4へのUSBブートローダー書き込み
- 基板上LED点滅
- HIDマクロキーボード
- RE12000XH1-V02のCW／CCW入力
- Python／hidapiホストアプリによるポインターサイズ変更

## このZIPで未完了

- 最終オフライン配布
- ch32fun許可リストサブセット
- 別PC／別ユーザー検証
- macOS Apple Silicon
- 正式VID:PIDとUSBシリアル番号

## test9での構造変更

- PC側Pythonを`workspace/exercises/02_rotary_cursor_size/host/`へ移設
- `workspace/host`を廃止
- Makefile、`cursorapp`、`setup`、`doctor`を新配置へ更新
- ZIP構造、Python構文、参照整合性は静的検査済み
- 新配置でのWindows実機ビルド、書き込み、HID受信、ポインター変更は再検証待ち
