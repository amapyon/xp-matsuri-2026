﻿# Test Scope

対象Devkit: `0.4.1-test9`

## このZIPで確認すること

- Windows 11 x64でMSYS2を使用せず開発環境を起動できる
- `setup`でxPack Build Tools、RISC-V GCC、Python、hidapi、ch32fun、rv003usbを取得できる
- `doctor`と`versions`が成功する
- 基板上LED演習をビルドして書き込める
- D5スイッチのHIDキーボード演習を実行できる
- RE12000XH1-V02をD8、D9、GNDへ配線できる
- Vendor-defined HID `1209:C004`として列挙できる
- PC側Pythonが`workspace/exercises/02_rotary_cursor_size/host/`にあり、`workspace/host`が存在しない
- `make app`と`cursorapp`が新配置のPythonを起動できる
- PythonホストアプリがCW／CCWを受信できる
- Windowsのポインターサイズを段階的に変更できる
- Ctrl+C終了時または`cursorrestore`で設定を復元できる
- コンソール再起動後に同じ操作を再現できる

## このZIPでは確認済みとしないこと

- 新しい演習内`host`配置でのWindows実機再検証
- 最終オフライン参加者向けZIP
- ch32fun許可リストサブセット
- ネットワーク切断状態の初回セットアップ
- 別のWindows 11 x64 PC
- 管理者権限のない別ユーザー
- macOS Apple Silicon
- 3台同時接続
- 正式アプリケーションVID:PID
- MCU UUID由来USBシリアル番号
- HID経由自動ブートローダー移行
