﻿# Troubleshooting

## エンコーダーを回しても表示されない

1. `make app`が起動中か確認する
2. `make hidcheck`を実行する
3. D8-A/CLK、D9-B/DT、GND-C/COMを確認する
4. 3.3Vまたは5Vへ接続していないことを確認する
5. `cursorapp --dry-run`でHIDイベントだけ確認する
6. `report`の結果を保存する

## 時計回りと反時計回りが逆

```text
make app-reverse
```

またはD8とD9の信号線を入れ替えます。

## 1クリックで2段階動く／反応しない

エンコーダーの機械構造により1クリックあたりの状態遷移数が異なる可能性があります。`uiap_rotary_cursor.c`の`UIAP_COUNTS_PER_DETENT`を4から2へ変更して再検証します。必須演習へ採用する前に配布予定部品で固定してください。

## ポインターサイズが戻らない

```text
cursorrestore
```

それでも戻らない場合は、Windows設定の「アクセシビリティ」→「マウスポインターとタッチ」から手動で戻します。

## `[UIAP-A105]`で終了する

- USBケーブルの抜け
- UIAPduinoのリセット
- HIDの再列挙
- 別プロセスがデバイスを開いている

を確認します。アプリは自動再接続せず、明確なエラーを表示して終了します。

## D5スイッチ

今回のファームウェアはD5/PC3を初期化も参照もしません。既存のモメンタリスイッチは接続したままで構いません。


## UIAP-E207: hidapi import verification failed

Version `0.3.0-test5` embedded Python code in a PowerShell native-process argument.
Windows PowerShell could remove nested quotes, causing a Python `SyntaxError` even when hidapi was installed correctly.

Version `0.4.1-test9` executes `scripts/python/hidapi_probe.py` as a file and does not use `python -c`.
After applying the update, run:

```text
setup
doctor
```

Previously downloaded archives are reused.


## RE12000XH1-V02固有

### 回しても反応しない

- 軸側から見た端子順がA-C-Bであることを確認する
- ピン側から見て左右を取り違えていないか確認する
- CがGNDへ接続されていることを確認する
- 3.3Vや5Vを接続していないことを確認する
- 金属固定タブへジャンパー線を接続していないか確認する
- `cursorapp --dry-run`でイベントだけ確認する

### 回転方向が逆

```text
make app-reverse
```

またはAとBの配線を入れ替えます。ワークショップではプログラム側の反転を優先します。

### 1クリックで複数段階変化する

コンソールログと配線写真を記録してください。ファームウェアは製品仕様の24クリック／24パルスに合わせ、4エッジで1クリックとしてあります。実物の接点特性を確認してから`UIAP_EDGES_PER_CLICK`を変更します。

## `[UIAP-A101]`またはホストPythonが見つからない

標準配置:

```text
workspace/exercises/02_rotary_cursor_size/host/cursor_size_host.py
```

次の旧配置は使用しません。

```text
workspace/host/cursor_size_host.py
```

確認:

1. `doctor`を実行する
2. 演習ディレクトリで`make app`を実行する
3. `scripts/cmd/cursorapp.cmd`と演習Makefileが新配置を参照していることを確認する
4. 旧`workspace/host`を手作業で復元しない

Devkit全体の診断用Pythonは`scripts/python`にあり、演習固有ホストアプリとは別です。
