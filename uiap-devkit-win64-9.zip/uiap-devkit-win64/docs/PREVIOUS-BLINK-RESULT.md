# Previous validation baseline

`uiap-devkit-win64-2.zip`は、Windows 11 x64実機で次が確認済みです。

- `start-uiap.cmd`
- `setup`
- `sample`
- `make clean`
- `make flash`
- USBブートローダー`1209:B803`
- 基板上LEDのLチカ
- コンソール再起動後の再現

本版はその構成を基準に、rv003usb HIDキーボードを追加しています。
