# Source Information

この版はオンライン検証用ブートストラップです。`setup`が取得アーカイブを`runtime/downloads`へ保存します。

```text
workspace/deps/VERSIONS.md
runtime/downloads/SHA256-ACTUAL.txt
```

hidapi wheelはPyPI掲載のSHA-256を検証します。Python embeddable ZIPは本PoCでは取得後ハッシュを記録しますが、上流署名・Sigstore検証は未実装です。

最終配布版では、必要な対応ソース、ビルドスクリプト、変更パッチ、ライセンス本文、Pythonの第三者ライセンスを保存してください。
