# Third-Party Notices

この初期ZIPは第三者製コンパイラやPythonバイナリ本体を含みません。`setup`が固定URLから次を取得します。

- xPack Windows Build Tools 4.4.1-3
- xPack GNU RISC-V Embedded GCC 14.2.0-3
- ch32fun
- rv003usb
- ch32funに含まれるminichlink
- Python 3.14.6 embeddable x64
- hidapi 0.15.0 CPython 3.14 Windows x64 wheel

Python配布物の`LICENSE.txt`、hidapi wheelの`.dist-info`およびライセンス情報、各上流配布物の著作権表示を削除しないでください。

この検証版を第三者へ再配布する前に、最終的に含まれる正確なファイル単位でライセンス監査を行ってください。
