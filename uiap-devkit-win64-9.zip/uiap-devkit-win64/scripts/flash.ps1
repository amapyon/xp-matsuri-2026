﻿[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)]
    [string]$Image,
    [int]$TimeoutSeconds = 45,
    [string]$ExpectedApplicationVidPid = '',
    [int]$ApplicationTimeoutSeconds = 20,
    [string]$ExpectedResult = ''
)

$ErrorActionPreference = 'Stop'

function Fail([string]$Code, [string]$Message) {
    Write-Host "[$Code] $Message" -ForegroundColor Red
    exit 1
}

if (-not $env:UIAP_DEVKIT_ROOT) {
    Fail 'UIAP-F201' 'UIAP_DEVKIT_ROOT is not set. Start with start-uiap.cmd.'
}

$imagePath = [IO.Path]::GetFullPath($Image)
if (-not (Test-Path -LiteralPath $imagePath)) {
    Fail 'UIAP-F202' "Firmware image was not found: $imagePath"
}

$minichlink = Join-Path $env:UIAP_DEVKIT_ROOT 'workspace\deps\ch32fun\minichlink\minichlink.exe'
if (-not (Test-Path -LiteralPath $minichlink)) {
    Fail 'UIAP-F203' 'minichlink.exe is missing. Run setup and doctor.'
}

function Get-PresentPnpMatches([string]$Pattern) {
    try {
        return @(Get-CimInstance Win32_PnPEntity | Where-Object {
            $_.PNPDeviceID -and
            ($_.PNPDeviceID -match $Pattern) -and
            (($null -eq $_.ConfigManagerErrorCode) -or ($_.ConfigManagerErrorCode -eq 0))
        })
    }
    catch {
        Fail 'UIAP-F204' ('USB enumeration failed: ' + $_.Exception.Message)
    }
}

function Get-Bootloaders {
    # Count one physical USB parent per board. Matching every VID/PID-bearing
    # PnP row can count the USB parent and HID child as separate boards.
    return @(Get-PresentPnpMatches '^USB\\VID_1209&PID_B803\\')
}

Write-Host ''
Write-Host '[UIAP] Connect only one UIAPduino.'
Write-Host '[UIAP] To enter the USB bootloader:'
Write-Host '  1. Hold the RESET button.'
Write-Host '  2. Connect the USB cable.'
Write-Host '  3. Release the RESET button.'
Write-Host "[UIAP] Waiting for bootloader VID:PID 1209:B803 for $TimeoutSeconds seconds..."

$deadline = (Get-Date).AddSeconds($TimeoutSeconds)
$devices = @()
do {
    $devices = @(Get-Bootloaders)
    if ($devices.Count -gt 1) {
        Write-Host '[UIAP] Present bootloader USB devices:' -ForegroundColor Yellow
        $devices | Select-Object Name, Status, PNPDeviceID | Format-Table -AutoSize
        Fail 'UIAP-F205' 'Multiple physical bootloaders were detected. Disconnect boards until only one remains.'
    }
    if ($devices.Count -eq 1) { break }
    Start-Sleep -Milliseconds 500
} while ((Get-Date) -lt $deadline)

if ($devices.Count -ne 1) {
    Fail 'UIAP-F206' 'Bootloader 1209:B803 was not detected. Check the cable, reset sequence, USB port, and direct connection.'
}

Write-Host '[UIAP] One physical bootloader detected. Starting flash.'
Write-Host ('[UIAP] Bootloader: ' + $devices[0].PNPDeviceID)
Write-Host ('[UIAP] Image: ' + $imagePath)

& $minichlink '-c' '0x1209b803' '-w' $imagePath 'flash' '-b'
$code = $LASTEXITCODE
if ($code -ne 0) {
    Fail 'UIAP-F207' "minichlink failed with exit code $code."
}

Write-Host '[UIAP] Flash completed successfully.' -ForegroundColor Green

if ($ExpectedApplicationVidPid) {
    if ($ExpectedApplicationVidPid -notmatch '^(?<vid>[0-9A-Fa-f]{4}):(?<pid>[0-9A-Fa-f]{4})$') {
        Fail 'UIAP-F208' "Invalid application VID:PID: $ExpectedApplicationVidPid"
    }

    $pattern = 'VID_' + $Matches.vid.ToUpperInvariant() + '&PID_' + $Matches.pid.ToUpperInvariant()
    Write-Host "[UIAP] Waiting for application HID $ExpectedApplicationVidPid for $ApplicationTimeoutSeconds seconds..."
    $appDeadline = (Get-Date).AddSeconds($ApplicationTimeoutSeconds)
    $appDevices = @()
    do {
        $appDevices = @(Get-PresentPnpMatches $pattern)
        if ($appDevices.Count -gt 0) { break }
        Start-Sleep -Milliseconds 500
    } while ((Get-Date) -lt $appDeadline)

    if ($appDevices.Count -eq 0) {
        Fail 'UIAP-F209' "Firmware was written, but application device $ExpectedApplicationVidPid was not detected. Unplug and reconnect the board, then run hidcheck."
    }

    Write-Host "[UIAP] Application device detected: $ExpectedApplicationVidPid" -ForegroundColor Green
    $appDevices | Select-Object -First 3 Name, Status, PNPDeviceID | Format-Table -AutoSize
}

if ($ExpectedResult) {
    Write-Host ('[UIAP] Expected result: ' + $ExpectedResult)
}
exit 0
