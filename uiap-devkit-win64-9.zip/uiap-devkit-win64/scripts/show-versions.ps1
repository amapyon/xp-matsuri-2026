﻿[CmdletBinding()]
param()

if (-not $env:UIAP_DEVKIT_ROOT) {
    Write-Host '[UIAP-E401] UIAP_DEVKIT_ROOT is not set. Start with start-uiap.cmd.' -ForegroundColor Red
    exit 1
}

$root = [IO.Path]::GetFullPath($env:UIAP_DEVKIT_ROOT)
Write-Host 'UIAP Devkit: 0.4.1-test9'
Write-Host ('Windows: ' + [Environment]::OSVersion.VersionString)
Write-Host ('64-bit OS: ' + [Environment]::Is64BitOperatingSystem)

$make = Join-Path $root 'runtime\build-tools\bin\make.exe'
$gcc = Join-Path $root 'runtime\toolchain\bin\riscv-none-elf-gcc.exe'
$mini = Join-Path $root 'workspace\deps\ch32fun\minichlink\minichlink.exe'
$python = Join-Path $root 'runtime\python\python.exe'
$hidapiProbe = Join-Path $root 'scripts\python\hidapi_probe.py'

if (Test-Path $make) { & $make --version | Select-Object -First 1 } else { Write-Host 'make: missing' }
if (Test-Path $gcc) { & $gcc --version | Select-Object -First 1 } else { Write-Host 'gcc: missing' }
if (Test-Path $mini) { Write-Host ('minichlink: ' + $mini) } else { Write-Host 'minichlink: missing' }
if (Test-Path $python) {
    & $python --version
    if (Test-Path $hidapiProbe) {
        & $python $hidapiProbe
    }
    else {
        Write-Host 'hidapi probe: missing'
    }
} else { Write-Host 'python: missing' }

$versionsFile = Join-Path $root 'workspace\deps\VERSIONS.md'
if (Test-Path $versionsFile) {
    Write-Host ''
    Get-Content $versionsFile
}
