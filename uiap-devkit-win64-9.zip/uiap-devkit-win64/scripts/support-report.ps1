﻿[CmdletBinding()]
param()

if (-not $env:UIAP_DEVKIT_ROOT) {
    Write-Host '[UIAP-E501] UIAP_DEVKIT_ROOT is not set. Start with start-uiap.cmd.' -ForegroundColor Red
    exit 1
}

$root = [IO.Path]::GetFullPath($env:UIAP_DEVKIT_ROOT)
$logs = Join-Path $root 'logs'
New-Item -ItemType Directory -Force -Path $logs | Out-Null
$out = Join-Path $logs 'support-report.txt'

$make = Join-Path $root 'runtime\build-tools\bin\make.exe'
$gcc = Join-Path $root 'runtime\toolchain\bin\riscv-none-elf-gcc.exe'
$mini = Join-Path $root 'workspace\deps\ch32fun\minichlink\minichlink.exe'
$python = Join-Path $root 'runtime\python\python.exe'
$hidapiProbe = Join-Path $root 'scripts\python\hidapi_probe.py'
$sample = Join-Path $root 'workspace\exercises\02_rotary_cursor_size'
$hostApp = Join-Path $sample 'host\cursor_size_host.py'

$lines = @()
$lines += 'UIAP support report'
$lines += 'Devkit-Version: 0.4.1-test9'
$lines += ('Generated: ' + (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'))
$lines += ('OS: ' + [Environment]::OSVersion.VersionString)
$lines += ('64-bit OS: ' + [Environment]::Is64BitOperatingSystem)
$lines += ('PowerShell: ' + $PSVersionTable.PSVersion)
$lines += ('Devkit root: <UIAP_DEVKIT_ROOT>')
$lines += ('Current directory: ' + ((Get-Location).Path -replace [regex]::Escape($root), '<UIAP_DEVKIT_ROOT>'))
$lines += ('make exists: ' + (Test-Path $make))
$lines += ('gcc exists: ' + (Test-Path $gcc))
$lines += ('minichlink exists: ' + (Test-Path $mini))
$lines += ('python exists: ' + (Test-Path $python))
$lines += ('sample exists: ' + (Test-Path $sample))
$lines += ('exercise host app exists: ' + (Test-Path $hostApp))
$lines += ('obsolete workspace host exists: ' + (Test-Path (Join-Path $root 'workspace\host')))
$lines += ''

if (Test-Path $make) { $lines += ('make: ' + ((& $make --version | Select-Object -First 1) -join ' ')) }
if (Test-Path $gcc) { $lines += ('gcc: ' + ((& $gcc --version | Select-Object -First 1) -join ' ')) }
if (Test-Path $python) {
    $lines += ('python: ' + ((& $python --version 2>&1) -join ' '))
    if (Test-Path $hidapiProbe) {
        $lines += ('hidapi probe: ' + ((& $python $hidapiProbe 2>&1) -join ' | '))
    }
    else {
        $lines += 'hidapi probe: missing'
    }
}

try {
    $boot = @(Get-CimInstance Win32_PnPEntity | Where-Object { $_.PNPDeviceID -like 'USB\VID_1209&PID_B803*' })
    $app = @(Get-CimInstance Win32_PnPEntity | Where-Object { $_.PNPDeviceID -match 'VID_1209&PID_C004' })
    $lines += ('bootloader 1209:B803 count: ' + $boot.Count)
    $lines += ('application 1209:C004 rows: ' + $app.Count)
}
catch {
    $lines += ('PnP detection error: ' + $_.Exception.Message)
}

Set-Content -LiteralPath $out -Value $lines -Encoding UTF8
Write-Host "[UIAP] Support report created: $out"
