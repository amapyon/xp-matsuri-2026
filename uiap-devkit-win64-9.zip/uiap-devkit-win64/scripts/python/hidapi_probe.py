#!/usr/bin/env python3
"""Verify the bundled hidapi module without shell-embedded Python code."""

from __future__ import annotations

import sys


def main() -> int:
    try:
        import hid  # type: ignore[import-not-found]
    except Exception as exc:
        print(f"hidapi import: FAIL: {exc}", file=sys.stderr)
        return 1

    print(f"Python: {sys.version.split()[0]}")
    print(f"hidapi: {getattr(hid, '__file__', '<unknown>')}")
    print("hidapi import: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
