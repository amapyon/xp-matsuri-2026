﻿[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

function Write-Step([string]$Message) {
    Write-Host "[UIAP] $Message"
}

function Fail([string]$Code, [string]$Message) {
    Write-Host "[$Code] $Message" -ForegroundColor Red
    exit 1
}

function Download-File([string]$Name, [string]$Url, [string]$Destination) {
    if (Test-Path -LiteralPath $Destination) {
        Write-Step "Using cached download: $Name"
        return
    }
    $parent = Split-Path -Parent $Destination
    New-Item -ItemType Directory -Force -Path $parent | Out-Null
    $part = "$Destination.part"
    Remove-Item -LiteralPath $part -Force -ErrorAction SilentlyContinue
    Write-Step "Downloading: $Name"
    try {
        Invoke-WebRequest -UseBasicParsing -Uri $Url -OutFile $part
        Move-Item -LiteralPath $part -Destination $Destination -Force
    }
    catch {
        Remove-Item -LiteralPath $part -Force -ErrorAction SilentlyContinue
        throw
    }
}

function Verify-Archive(
    [string]$Name,
    [string]$Archive,
    [string]$ShaUrl,
    [string]$ExpectedSha256
) {
    if ($ExpectedSha256) {
        $expected = $ExpectedSha256.ToLowerInvariant()
    }
    elseif ($ShaUrl) {
        $shaFile = "$Archive.sha"
        Download-File -Name "$Name SHA-256" -Url $ShaUrl -Destination $shaFile
        $shaText = Get-Content -LiteralPath $shaFile -Raw
        $match = [regex]::Match($shaText, '(?i)[0-9a-f]{64}')
        if (-not $match.Success) {
            throw "Could not parse SHA-256 sidecar for $Name"
        }
        $expected = $match.Value.ToLowerInvariant()
    }
    else {
        Write-Step "No upstream SHA sidecar configured; recording actual hash: $Name"
        return
    }

    $actual = (Get-FileHash -Algorithm SHA256 -LiteralPath $Archive).Hash.ToLowerInvariant()
    if ($actual -ne $expected) {
        Remove-Item -LiteralPath $Archive -Force -ErrorAction SilentlyContinue
        throw "SHA-256 mismatch for $Name. Expected $expected but got $actual"
    }
    Write-Step "SHA-256 verified: $Name"
}

function Expand-SingleRootZip([string]$Name, [string]$Archive, [string]$Destination) {
    $marker = Join-Path $Destination '.uiap-extracted'
    if (Test-Path -LiteralPath $marker) {
        Write-Step "Already extracted: $Name"
        return
    }

    $stage = "$Destination.__extract"
    Remove-Item -LiteralPath $stage -Recurse -Force -ErrorAction SilentlyContinue
    Remove-Item -LiteralPath $Destination -Recurse -Force -ErrorAction SilentlyContinue
    New-Item -ItemType Directory -Force -Path $stage | Out-Null

    $expandSource = $Archive
    $temporaryZip = $null
    if ([IO.Path]::GetExtension($Archive).ToLowerInvariant() -ne '.zip') {
        $temporaryZip = "$Archive.__expand.zip"
        Copy-Item -LiteralPath $Archive -Destination $temporaryZip -Force
        $expandSource = $temporaryZip
    }

    Write-Step "Extracting: $Name"
    try {
        Expand-Archive -LiteralPath $expandSource -DestinationPath $stage -Force
    }
    finally {
        if ($temporaryZip) {
            Remove-Item -LiteralPath $temporaryZip -Force -ErrorAction SilentlyContinue
        }
    }

    $items = @(Get-ChildItem -LiteralPath $stage -Force)
    if (($items.Count -eq 1) -and $items[0].PSIsContainer) {
        $source = $items[0].FullName
    }
    else {
        $source = $stage
    }

    New-Item -ItemType Directory -Force -Path $Destination | Out-Null
    Get-ChildItem -LiteralPath $source -Force | ForEach-Object {
        Move-Item -LiteralPath $_.FullName -Destination $Destination -Force
    }
    Set-Content -LiteralPath $marker -Value $Name -Encoding ASCII
    Remove-Item -LiteralPath $stage -Recurse -Force -ErrorAction SilentlyContinue
}

if (-not $env:UIAP_DEVKIT_ROOT) {
    Fail 'UIAP-E201' 'UIAP_DEVKIT_ROOT is not set. Start with start-uiap.cmd.'
}

if (-not [Environment]::Is64BitOperatingSystem) {
    Fail 'UIAP-E202' 'This package requires 64-bit Windows 11.'
}

$root = [IO.Path]::GetFullPath($env:UIAP_DEVKIT_ROOT)
$runtime = Join-Path $root 'runtime'
$workspace = Join-Path $root 'workspace'
$downloads = Join-Path $runtime 'downloads'
$deps = Join-Path $workspace 'deps'
$python = Join-Path $runtime 'python'
$sitePackages = Join-Path $python 'Lib\site-packages'
New-Item -ItemType Directory -Force -Path $downloads, $deps | Out-Null

$packages = @(
    @{
        Name = 'xPack Windows Build Tools 4.4.1-3'
        Url = 'https://github.com/xpack-dev-tools/windows-build-tools-xpack/releases/download/v4.4.1-3/xpack-windows-build-tools-4.4.1-3-win32-x64.zip'
        File = 'xpack-windows-build-tools-4.4.1-3-win32-x64.zip'
        ShaUrl = 'https://github.com/xpack-dev-tools/windows-build-tools-xpack/releases/download/v4.4.1-3/xpack-windows-build-tools-4.4.1-3-win32-x64.zip.sha'
        ExpectedSha256 = $null
        Destination = (Join-Path $runtime 'build-tools')
    },
    @{
        Name = 'xPack GNU RISC-V Embedded GCC 14.2.0-3'
        Url = 'https://github.com/xpack-dev-tools/riscv-none-elf-gcc-xpack/releases/download/v14.2.0-3/xpack-riscv-none-elf-gcc-14.2.0-3-win32-x64.zip'
        File = 'xpack-riscv-none-elf-gcc-14.2.0-3-win32-x64.zip'
        ShaUrl = 'https://github.com/xpack-dev-tools/riscv-none-elf-gcc-xpack/releases/download/v14.2.0-3/xpack-riscv-none-elf-gcc-14.2.0-3-win32-x64.zip.sha'
        ExpectedSha256 = $null
        Destination = (Join-Path $runtime 'toolchain')
    },
    @{
        Name = 'ch32fun 1e4887e11d4bfa739ed5604524b69f5be9f9275b'
        Url = 'https://github.com/cnlohr/ch32fun/archive/1e4887e11d4bfa739ed5604524b69f5be9f9275b.zip'
        File = 'ch32fun-1e4887e11d4bfa739ed5604524b69f5be9f9275b.zip'
        ShaUrl = $null
        ExpectedSha256 = $null
        Destination = (Join-Path $deps 'ch32fun')
    },
    @{
        Name = 'rv003usb 75d926abe89a3002020b989015eab97ce5ad0470'
        Url = 'https://github.com/cnlohr/rv003usb/archive/75d926abe89a3002020b989015eab97ce5ad0470.zip'
        File = 'rv003usb-75d926abe89a3002020b989015eab97ce5ad0470.zip'
        ShaUrl = $null
        ExpectedSha256 = $null
        Destination = (Join-Path $deps 'rv003usb')
    },
    @{
        Name = 'Python 3.14.6 embeddable x64'
        Url = 'https://www.python.org/ftp/python/3.14.6/python-3.14.6-embed-amd64.zip'
        File = 'python-3.14.6-embed-amd64.zip'
        ShaUrl = $null
        ExpectedSha256 = $null
        Destination = $python
    },
    @{
        Name = 'hidapi 0.15.0 CPython 3.14 Windows x64 wheel'
        Url = 'https://files.pythonhosted.org/packages/cb/14/3b27516b2867e53545164ebd8ef45d0c36857d2a062036e788e56e2e34ce/hidapi-0.15.0-cp314-cp314-win_amd64.whl'
        File = 'hidapi-0.15.0-cp314-cp314-win_amd64.whl'
        ShaUrl = $null
        ExpectedSha256 = 'df0dd435562654e27ad0c7d045074eb1e1e016b09167dd48a258dec1ce4b9127'
        Destination = $sitePackages
    }
)

try {
    foreach ($package in $packages) {
        $archive = Join-Path $downloads $package.File
        Download-File -Name $package.Name -Url $package.Url -Destination $archive
        Verify-Archive -Name $package.Name -Archive $archive -ShaUrl $package.ShaUrl -ExpectedSha256 $package.ExpectedSha256
        Expand-SingleRootZip -Name $package.Name -Archive $archive -Destination $package.Destination
    }
}
catch {
    Write-Host $_.Exception.Message -ForegroundColor Red
    Fail 'UIAP-E203' 'Setup failed while downloading or extracting. Check the network and run setup again.'
}

# Enable the local site-packages directory in the official embeddable Python.
$pth = Join-Path $python 'python314._pth'
if (-not (Test-Path -LiteralPath $pth)) {
    Fail 'UIAP-E206' "Python path configuration was not found: $pth"
}
$pthContent = @(
    'python314.zip',
    '.',
    'Lib\site-packages',
    'import site'
)
Set-Content -LiteralPath $pth -Value $pthContent -Encoding ASCII

$required = @(
    (Join-Path $runtime 'build-tools\bin\make.exe'),
    (Join-Path $runtime 'toolchain\bin\riscv-none-elf-gcc.exe'),
    (Join-Path $deps 'ch32fun\ch32fun\ch32fun.mk'),
    (Join-Path $deps 'ch32fun\minichlink\minichlink.exe'),
    (Join-Path $deps 'rv003usb\rv003usb\rv003usb.c'),
    (Join-Path $python 'python.exe'),
    (Join-Path $workspace 'exercises\02_rotary_cursor_size\host\cursor_size_host.py')
)
foreach ($path in $required) {
    if (-not (Test-Path -LiteralPath $path)) {
        Fail 'UIAP-E204' "Required file was not found after extraction: $path"
    }
}

$hidapiProbe = Join-Path $root 'scripts\python\hidapi_probe.py'
if (-not (Test-Path -LiteralPath $hidapiProbe)) {
    Fail 'UIAP-E208' "hidapi probe script was not found: $hidapiProbe"
}
& (Join-Path $python 'python.exe') $hidapiProbe
if ($LASTEXITCODE -ne 0) {
    Fail 'UIAP-E207' 'Bundled Python could not import hidapi.'
}

$hashLines = @()
foreach ($package in $packages) {
    $archive = Join-Path $downloads $package.File
    $hash = (Get-FileHash -Algorithm SHA256 -LiteralPath $archive).Hash.ToLowerInvariant()
    $hashLines += "$hash  $($package.File)"
}
Set-Content -LiteralPath (Join-Path $downloads 'SHA256-ACTUAL.txt') -Value $hashLines -Encoding ASCII

$versions = @'
# Fixed dependencies for uiap-devkit-win64 0.4.1-test9

| Component | Version / commit | Source |
|---|---|---|
| xPack Windows Build Tools | 4.4.1-3 | xpack-dev-tools/windows-build-tools-xpack |
| xPack GNU RISC-V Embedded GCC | 14.2.0-3 | xpack-dev-tools/riscv-none-elf-gcc-xpack |
| ch32fun | 1e4887e11d4bfa739ed5604524b69f5be9f9275b | cnlohr/ch32fun |
| rv003usb | 75d926abe89a3002020b989015eab97ce5ad0470 | cnlohr/rv003usb |
| minichlink | bundled in the pinned ch32fun commit | cnlohr/ch32fun/minichlink |
| Python embeddable | 3.14.6 x64 | python.org |
| hidapi wheel | 0.15.0 cp314 win_amd64 | PyPI |
'@
Set-Content -LiteralPath (Join-Path $deps 'VERSIONS.md') -Value $versions -Encoding UTF8

$complete = @(
    'UIAP Devkit setup complete',
    'Version: 0.4.1-test9',
    ('Completed: ' + (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'))
)
Set-Content -LiteralPath (Join-Path $runtime 'setup-complete.txt') -Value $complete -Encoding ASCII

Write-Step 'Setup completed.'
& (Join-Path $root 'scripts\doctor.ps1')
if ($LASTEXITCODE -ne 0) {
    Fail 'UIAP-E205' 'Setup finished, but doctor reported an error.'
}
Write-Step 'Doctor result: PASS'
Write-Host ''
Write-Host 'Next commands:'
Write-Host '  sample'
Write-Host '  make'
Write-Host '  make flash'
Write-Host '  make app'
