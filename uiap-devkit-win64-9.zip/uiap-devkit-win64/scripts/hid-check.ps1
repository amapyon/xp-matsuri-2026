﻿[CmdletBinding()]
param(
    [string]$VidPid = '1209:C003'
)

$ErrorActionPreference = 'Stop'

function Fail([string]$Code, [string]$Message) {
    Write-Host "[$Code] $Message" -ForegroundColor Red
    exit 1
}

if ($VidPid -notmatch '^(?<vid>[0-9A-Fa-f]{4}):(?<pid>[0-9A-Fa-f]{4})$') {
    Fail 'UIAP-H101' "Invalid VID:PID: $VidPid"
}

$pattern = 'VID_' + $Matches.vid.ToUpperInvariant() + '&PID_' + $Matches.pid.ToUpperInvariant()
try {
    $devices = @(Get-CimInstance Win32_PnPEntity | Where-Object {
        $_.PNPDeviceID -and ($_.PNPDeviceID -match $pattern)
    })
}
catch {
    Fail 'UIAP-H102' ('Could not enumerate Plug and Play devices: ' + $_.Exception.Message)
}

if ($devices.Count -eq 0) {
    Fail 'UIAP-H103' "HID application $VidPid was not found. Check make flash, reconnect the board, and confirm the data USB cable."
}

Write-Host "[UIAP] HID application detected: $VidPid" -ForegroundColor Green
$devices | Select-Object Name, Status, PNPDeviceID | Format-Table -AutoSize
Write-Host '[UIAP] Device check: PASS'
exit 0
