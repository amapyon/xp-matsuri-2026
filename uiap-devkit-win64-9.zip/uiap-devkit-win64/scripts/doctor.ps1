﻿[CmdletBinding()]
param()

$ErrorActionPreference = 'Continue'
$failures = 0

function Pass([string]$Name, [string]$Detail) {
    Write-Host "[PASS] $Name - $Detail"
}
function Fail([string]$Code, [string]$Name, [string]$Detail) {
    $script:failures++
    Write-Host "[$Code] $Name - $Detail" -ForegroundColor Red
}

if (-not $env:UIAP_DEVKIT_ROOT) {
    Fail 'UIAP-E301' 'Environment' 'UIAP_DEVKIT_ROOT is not set. Start with start-uiap.cmd.'
    exit 1
}

$root = [IO.Path]::GetFullPath($env:UIAP_DEVKIT_ROOT)
Pass 'Devkit root' $root

if ([Environment]::OSVersion.Platform -ne [PlatformID]::Win32NT) {
    Fail 'UIAP-E302' 'Operating system' 'Windows is required.'
} else {
    Pass 'Operating system' ([Environment]::OSVersion.VersionString)
}

if (-not [Environment]::Is64BitOperatingSystem) {
    Fail 'UIAP-E303' 'Architecture' '64-bit Windows is required.'
} else {
    Pass 'Architecture' 'x64-capable Windows'
}

$checks = @(
    @('UIAP-E304', 'GNU Make', (Join-Path $root 'runtime\build-tools\bin\make.exe')),
    @('UIAP-E305', 'RISC-V GCC', (Join-Path $root 'runtime\toolchain\bin\riscv-none-elf-gcc.exe')),
    @('UIAP-E306', 'ch32fun', (Join-Path $root 'workspace\deps\ch32fun\ch32fun\ch32fun.mk')),
    @('UIAP-E307', 'rv003usb C', (Join-Path $root 'workspace\deps\rv003usb\rv003usb\rv003usb.c')),
    @('UIAP-E308', 'rv003usb ASM', (Join-Path $root 'workspace\deps\rv003usb\rv003usb\rv003usb.S')),
    @('UIAP-E309', 'minichlink', (Join-Path $root 'workspace\deps\ch32fun\minichlink\minichlink.exe')),
    @('UIAP-E315', 'rotary source', (Join-Path $root 'workspace\exercises\02_rotary_cursor_size\uiap_rotary_cursor.c')),
    @('UIAP-E316', 'rotary USB config', (Join-Path $root 'workspace\exercises\02_rotary_cursor_size\usb_config.h')),
    @('UIAP-E317', 'cursor host app', (Join-Path $root 'workspace\exercises\02_rotary_cursor_size\host\cursor_size_host.py')),
    @('UIAP-E318', 'bundled Python', (Join-Path $root 'runtime\python\python.exe'))
)

$obsoleteHost = Join-Path $root 'workspace\host'
if (Test-Path -LiteralPath $obsoleteHost) {
    Fail 'UIAP-E321' 'obsolete host directory' "Remove obsolete directory: $obsoleteHost"
}
else {
    Pass 'host application layout' 'exercise-local host directory; workspace\host is absent'
}

foreach ($check in $checks) {
    if (Test-Path -LiteralPath $check[2]) {
        Pass $check[1] $check[2]
    } else {
        Fail $check[0] $check[1] "Missing: $($check[2])"
    }
}

$python = Join-Path $root 'runtime\python\python.exe'
$hidapiProbe = Join-Path $root 'scripts\python\hidapi_probe.py'
if ((Test-Path -LiteralPath $python) -and (Test-Path -LiteralPath $hidapiProbe)) {
    $pythonResult = (& $python $hidapiProbe 2>&1 | Out-String)
    if ($LASTEXITCODE -ne 0) {
        Fail 'UIAP-E319' 'Python hidapi' $pythonResult.Trim()
    }
    else {
        Pass 'Python hidapi' $pythonResult.Trim()
    }
}
elseif (-not (Test-Path -LiteralPath $hidapiProbe)) {
    Fail 'UIAP-E320' 'Python hidapi probe' "Missing: $hidapiProbe"
}

$make = Join-Path $root 'runtime\build-tools\bin\make.exe'
$sample = Join-Path $root 'workspace\exercises\02_rotary_cursor_size'
if ((Test-Path -LiteralPath $make) -and (Test-Path -LiteralPath (Join-Path $sample 'Makefile'))) {
    Push-Location $sample
    try {
        $dryRunOutput = (& $make '--no-print-directory' '-n' 'build' 2>&1 | Out-String)
        $dryRunExit = $LASTEXITCODE
        if ($dryRunExit -ne 0) {
            Fail 'UIAP-E310' 'Make dry run' "make -n build failed with exit code $dryRunExit"
        }
        elseif ($dryRunOutput -match '[A-Za-z]:\\') {
            Fail 'UIAP-E311' 'Make path compatibility' 'A backslash-form Windows path remains in a sh recipe. Re-extract the latest package.'
        }
        elseif ($dryRunOutput -notmatch 'rv003usb[\\/]rv003usb\.(c|S)') {
            Fail 'UIAP-E314' 'rv003usb build integration' 'The dry run does not include rv003usb.c or rv003usb.S.'
        }
        else {
            Pass 'Make path compatibility' 'ch32fun and rv003usb paths use forward slashes for xPack sh.exe'
        }
    }
    finally {
        Pop-Location
    }
}

if ($failures -eq 0) {
    Write-Host '[UIAP] Doctor result: PASS'
    exit 0
}

Write-Host "[UIAP] Doctor result: FAIL ($failures error(s))" -ForegroundColor Red
Write-Host 'Run setup again. If it still fails, run report and keep the complete output.'
exit 1
