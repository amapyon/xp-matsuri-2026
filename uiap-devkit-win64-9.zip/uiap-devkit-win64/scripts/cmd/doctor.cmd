@echo off
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%UIAP_DEVKIT_ROOT%\scripts\doctor.ps1"
exit /b %errorlevel%
