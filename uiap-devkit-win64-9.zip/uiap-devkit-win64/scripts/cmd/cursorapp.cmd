@echo off
if not defined UIAP_PYTHON set "UIAP_PYTHON=%UIAP_RUNTIME%\python\python.exe"
if not exist "%UIAP_PYTHON%" (
  echo [UIAP-A101] Bundled Python was not found. Run setup first.
  exit /b 1
)
"%UIAP_PYTHON%" "%UIAP_WORKSPACE%\exercises\02_rotary_cursor_size\host\cursor_size_host.py" %*
exit /b %ERRORLEVEL%
