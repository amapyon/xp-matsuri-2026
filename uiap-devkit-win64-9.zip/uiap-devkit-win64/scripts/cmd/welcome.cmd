@echo off
echo.
echo ============================================================
echo  UIAP Devkit console - Windows 11 x64 - 0.4.1-test9
echo ============================================================
echo Root      : %UIAP_DEVKIT_ROOT%
echo Workspace : %UIAP_WORKSPACE%
echo.
if exist "%UIAP_RUNTIME%\setup-complete.txt" (
  echo Environment status: configured
  echo Next: sample
) else (
  echo Environment status: not configured
  echo Next: setup
)
echo.
echo Commands: setup, doctor, versions, sample, macro, blink, hidcheck, cursorapp, cursorlist, cursorrestore, report
echo.
