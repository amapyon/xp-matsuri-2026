@echo off
if not defined UIAP_WORKSPACE (
  echo [UIAP-E102] UIAP_WORKSPACE is not set. Start with start-uiap.cmd.
  exit /b 1
)
cd /d "%UIAP_WORKSPACE%\exercises\02_rotary_cursor_size"
echo Current exercise:
echo %CD%
echo.
echo Run: make
echo Then: make flash
echo Then: make app
