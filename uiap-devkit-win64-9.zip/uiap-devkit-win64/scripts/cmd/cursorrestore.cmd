@echo off
call "%UIAP_DEVKIT_ROOT%\scripts\cmd\cursorapp.cmd" --restore-from-state
exit /b %ERRORLEVEL%
