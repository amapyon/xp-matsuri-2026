@echo off
call "%UIAP_DEVKIT_ROOT%\scripts\cmd\hidcheck.cmd"
if errorlevel 1 exit /b 1

echo.
echo [UIAP] Caps LockをOFFにしてください。
echo [UIAP] メモ帳を開きます。入力位置をクリックしてからスイッチを1回押してください。
echo [UIAP] 期待される文字列: AbCdE
echo [UIAP] スイッチを押し続けても、1回の押下につき1回だけ送信します。
echo.
start "" notepad.exe
exit /b 0
