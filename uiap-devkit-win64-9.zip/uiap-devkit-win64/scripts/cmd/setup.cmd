@echo off
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%UIAP_DEVKIT_ROOT%\scripts\setup.ps1"
exit /b %errorlevel%
