@echo off
set "UIAP_HID_VIDPID=%~1"
if not defined UIAP_HID_VIDPID set "UIAP_HID_VIDPID=1209:C004"
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%UIAP_DEVKIT_ROOT%\scripts\hid-check.ps1" -VidPid "%UIAP_HID_VIDPID%"
exit /b %ERRORLEVEL%
