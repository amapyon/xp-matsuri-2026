@echo off
if not defined UIAP_WORKSPACE (
  echo [UIAP-E102] UIAP_WORKSPACE is not set. Start with start-uiap.cmd.
  exit /b 1
)
cd /d "%UIAP_WORKSPACE%\exercises\01_macro_keyboard"
echo Current exercise:
echo %CD%
echo.
echo Run: make
