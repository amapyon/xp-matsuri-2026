﻿# UIAP Devkit Win64 0.4.1-test9

XP祭り2026「物理UIの電子工作を体験するワークショップ」向けWindows 11 x64検証パッケージです。

Windows版はMSYS2を使用しません。`start-uiap.cmd`から、xPack Windows Build Tools、xPack GNU RISC-V Embedded GCC、PowerShell補助スクリプト、同梱Pythonを使用するWindowsネイティブ環境を起動します。

## このZIPの位置付け

- 種別: オンライン・ブートストラップ検証版
- 対象OS: Windows 11 x64
- 管理者権限: 不要
- 初回`setup`: インターネット接続が必要
- ワークショップ当日の最終オフライン版: 未完成
- macOS版: このZIPには含まれない

初回`setup`が固定バージョンのツールと依存関係を取得します。取得後は同じファイルを再利用します。

## 対象ボード

- UIAPduino Pro Micro CH32V003 V1.4
- ブートローダーVID:PID: `1209:B803`
- USB 2.0 Low-Speed

アプリケーション側の`1209:C003`、`1209:C004`および`TEST3-001`、`TEST7-001`はPoC用一時値です。

## 1. 展開と起動

ZIPを完全に展開します。ZIP内から直接実行しないでください。

`start-uiap.cmd`をダブルクリックし、表示されたコンソールで次を実行します。

```text
setup
doctor
versions
```

## 2. 基板上LED点滅

```text
blink
make clean
make flash
```

期待動作:

- 基板上LEDが0.2秒点灯、0.8秒消灯を繰り返す

## 3. モメンタリスイッチによるHIDキーボード

配線:

```text
D5 / PC3 ─ スイッチ ─ GND
```

```text
macro
make clean
make flash
```

メモ帳など安全な入力先を選び、スイッチを1回押します。

期待動作:

```text
AbCdE
```

コマンドプロンプト、PowerShell、ブラウザのアドレス欄、パスワード欄では試さないでください。

## PC側Pythonの配置

演習固有のPC側Pythonプログラムは、対応する演習の`host`ディレクトリへ配置しています。

```text
workspace/exercises/02_rotary_cursor_size/host/cursor_size_host.py
```

トップレベルの`workspace/host`はありません。Devkit全体の診断用Pythonだけを`scripts/python`へ置きます。

## 4. RE12000XH1-V02ロータリーエンコーダー

使用部品:

- aitendo `RE12000XH1-V02`
- 24クリック／24パルス
- 3端子式: `A`、`C`、`B`
- 電源端子なし
- 押しボタンスイッチなし

配線前にUSBケーブルを外します。

| UIAPduino | RE12000XH1-V02 | 用途 |
|---|---|---|
| D8 / PC6 | A | A相、内部プルアップ |
| GND | C | 共通端子 |
| D9 / PC7 | B | B相、内部プルアップ |

`3.3V`、`5V`、金属固定タブには接続しません。D5の既存スイッチは接続したままで構いません。

```text
sample
make clean
make flash
make hidcheck
make app
```

期待動作:

- 時計回りでWindowsのポインターサイズが1段階大きくなる
- 反時計回りで1段階小さくなる
- コンソールに`CW`または`CCW`が表示される

回転方向が逆の場合:

```text
make app-reverse
```

Windows設定を変更せず、HIDイベントだけ確認する場合:

```text
cursorapp --dry-run
```

終了:

```text
Ctrl+C
```

通常終了時は起動前のポインターサイズへ戻します。戻らなかった場合:

```text
cursorrestore
```

配線図:

- `docs/wiring-re12000xh1-v02.png`
- `docs/wiring-re12000xh1-v02.svg`

## 補助コマンド

```text
setup
doctor
versions
blink
macro
sample
hidcheck
cursorlist
cursorapp
cursorrestore
report
```

## 既知の制限

- 初回セットアップはオンラインです。
- `ch32fun`はこの検証版では固定コミットの完全ツリーを取得します。参加者向け許可リストサブセットは未実装です。
- 最終オフラインZIP、別PC、別ユーザー、ネットワーク切断状態での完全検証は未完了です。
- USBシリアル番号は固定テスト値です。
- HID経由の自動ブートローダー移行は未実装です。
- Windowsのポインターサイズ変更は、Windows更新後に挙動が変わる可能性があります。

問題が発生した場合は、最初のエラーを省略せず保存し、次を実行してください。

```text
report
```
