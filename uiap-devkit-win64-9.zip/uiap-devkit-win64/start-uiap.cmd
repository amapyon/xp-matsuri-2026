@echo off
chcp 65001 >nul
set "UIAP_DEVKIT_ROOT=%~dp0"
if "%UIAP_DEVKIT_ROOT:~-1%"=="\" set "UIAP_DEVKIT_ROOT=%UIAP_DEVKIT_ROOT:~0,-1%"
set "UIAP_WORKSPACE=%UIAP_DEVKIT_ROOT%\workspace"
set "UIAP_RUNTIME=%UIAP_DEVKIT_ROOT%\runtime"
set "UIAP_TOOLCHAIN_BIN=%UIAP_RUNTIME%\toolchain\bin"
set "UIAP_FIRMWARE=%UIAP_DEVKIT_ROOT%\firmware"
set "UIAP_MINICHLINK=%UIAP_WORKSPACE%\deps\ch32fun\minichlink\minichlink.exe"
set "UIAP_PYTHON=%UIAP_RUNTIME%\python\python.exe"
set "PYTHONUTF8=1"
set "PATH=%UIAP_DEVKIT_ROOT%\scripts\cmd;%UIAP_RUNTIME%\build-tools\bin;%UIAP_TOOLCHAIN_BIN%;%UIAP_WORKSPACE%\deps\ch32fun\minichlink;%PATH%"

if not exist "%UIAP_WORKSPACE%" (
  echo [UIAP-E101] workspace was not found.
  echo Re-extract the ZIP and run start-uiap.cmd from the extracted folder.
  pause
  exit /b 1
)

cd /d "%UIAP_WORKSPACE%"
title UIAP Devkit Win64 0.4.1-test9
call "%UIAP_DEVKIT_ROOT%\scripts\cmd\welcome.cmd"
cmd.exe /K
