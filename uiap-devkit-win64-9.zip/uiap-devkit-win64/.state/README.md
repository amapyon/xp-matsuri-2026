# State

ホストアプリは実行中、起動前のWindowsポインターサイズを`cursor-size-session.json`へ一時保存します。正常終了時に削除します。異常終了後は`cursorrestore`で復旧できます。
