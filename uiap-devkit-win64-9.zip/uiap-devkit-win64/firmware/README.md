# Firmware

この検証版には、復旧用または事前ビルド済みファームウェアを含めません。

サンプルの生成物は`workspace/exercises/00_onboard_led_blink`で`make`を実行して生成します。
