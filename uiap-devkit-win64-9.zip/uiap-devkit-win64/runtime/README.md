# Runtime

Windows版はMSYS2を使用しません。

`setup`後に次が配置されます。

```text
build-tools/
toolchain/
python/
downloads/
```

- `build-tools/`: xPack Windows Build Tools 4.4.1-3
- `toolchain/`: xPack GNU RISC-V Embedded GCC 14.2.0-3
- `python/`: Python 3.14.6 embeddable x64とhidapi 0.15.0
- `downloads/`: オンライン検証版の取得キャッシュ

参加者は各ツールを直接実行せず、`start-uiap.cmd`、参加者向けコマンド、Makefileから使用します。
