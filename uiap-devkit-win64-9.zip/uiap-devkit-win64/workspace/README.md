# Workspace

参加者が使用する作業領域です。

```text
deps/
exercises/00_onboard_led_blink/
exercises/01_macro_keyboard/
exercises/02_rotary_cursor_size/
└── host/cursor_size_host.py
```

PC側プログラムは、対応する演習の`host`ディレクトリへ配置します。トップレベルの`workspace/host`は使用しません。PC側プログラムがない演習には空の`host`を作りません。

ロータリーエンコーダー演習:

```text
sample
make
make flash
make app
```

以前の演習:

```text
macro
blink
```
