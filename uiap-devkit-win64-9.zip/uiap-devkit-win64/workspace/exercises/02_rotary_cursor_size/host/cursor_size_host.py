from __future__ import annotations

import argparse
import atexit
import ctypes
from ctypes import wintypes
import json
import logging
import os
from pathlib import Path
import sys
import time
from typing import Any

if os.name != "nt":
    raise SystemExit("[UIAP-A102] This host application requires Windows.")

import winreg

try:
    import hid
except ImportError as exc:
    raise SystemExit("[UIAP-A103] hidapi is unavailable. Run setup, then doctor.") from exc

VID = 0x1209
PID = 0xC004
REPORT_ID = 0x01
EVENT_ROTATE = 0x01
CURSOR_KEY = r"Control Panel\Cursors"
CURSOR_VALUE = "CursorBaseSize"
DEFAULT_SIZE = 32
MIN_SIZE = 32
MAX_SIZE = 256
STEP_SIZE = 16
SPI_SETCURSORS = 0x0057
# Undocumented action used by the Windows Settings accessibility slider.
SPI_SETPOINTERSIZE = 0x2029
SPIF_UPDATEINIFILE = 0x0001
SPIF_SENDCHANGE = 0x0002
ERROR_ALREADY_EXISTS = 183
MUTEX_NAME = "Local\\XPfes2026_UIAP_Cursor_Size_Host"
ENCODER_MODEL = "RE12000XH1-V02"


def devkit_root() -> Path:
    value = os.environ.get("UIAP_DEVKIT_ROOT")
    if value:
        return Path(value).resolve()

    # Support direct execution from an exercise-local host directory.
    current = Path(__file__).resolve()
    for parent in current.parents:
        if (parent / "VERSION").is_file() and (parent / "workspace").is_dir():
            return parent
    raise RuntimeError("UIAP Devkit root could not be located. Start with start-uiap.cmd.")


ROOT = devkit_root()
STATE_PATH = ROOT / ".state" / "cursor-size-session.json"
LOG_DIR = ROOT / "logs"


def configure_logging() -> Path:
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    path = LOG_DIR / time.strftime("cursor-%Y%m%d-%H%M%S.log")
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(message)s",
        handlers=[
            logging.FileHandler(path, encoding="utf-8"),
        ],
    )
    return path


class CursorSizeController:
    def __init__(self) -> None:
        self.user32 = ctypes.WinDLL("user32", use_last_error=True)
        self.user32.SystemParametersInfoW.argtypes = [
            wintypes.UINT,
            wintypes.UINT,
            ctypes.c_void_p,
            wintypes.UINT,
        ]
        self.user32.SystemParametersInfoW.restype = wintypes.BOOL

    def get_size(self) -> int:
        try:
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, CURSOR_KEY) as key:
                value, _ = winreg.QueryValueEx(key, CURSOR_VALUE)
                return int(value)
        except FileNotFoundError:
            return DEFAULT_SIZE

    def set_size(self, size: int) -> str:
        size = max(MIN_SIZE, min(MAX_SIZE, int(size)))
        flags = SPIF_UPDATEINIFILE | SPIF_SENDCHANGE
        ctypes.set_last_error(0)
        ok = self.user32.SystemParametersInfoW(
            SPI_SETPOINTERSIZE,
            0,
            ctypes.c_void_p(size),
            flags,
        )
        if ok:
            return "SystemParametersInfo(0x2029)"

        primary_error = ctypes.get_last_error()
        # Fallback for Windows builds where the undocumented action is rejected.
        with winreg.CreateKeyEx(
            winreg.HKEY_CURRENT_USER,
            CURSOR_KEY,
            0,
            winreg.KEY_SET_VALUE,
        ) as key:
            winreg.SetValueEx(key, CURSOR_VALUE, 0, winreg.REG_DWORD, size)

        ctypes.set_last_error(0)
        reloaded = self.user32.SystemParametersInfoW(
            SPI_SETCURSORS,
            0,
            None,
            flags,
        )
        if not reloaded:
            fallback_error = ctypes.get_last_error()
            raise OSError(
                fallback_error,
                f"cursor reload failed; primary error={primary_error}",
            )
        return "registry + SPI_SETCURSORS fallback"


def acquire_mutex() -> int:
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel32.CreateMutexW.argtypes = [ctypes.c_void_p, wintypes.BOOL, wintypes.LPCWSTR]
    kernel32.CreateMutexW.restype = wintypes.HANDLE
    handle = kernel32.CreateMutexW(None, False, MUTEX_NAME)
    if not handle:
        raise OSError(ctypes.get_last_error(), "CreateMutexW failed")
    if ctypes.get_last_error() == ERROR_ALREADY_EXISTS:
        kernel32.CloseHandle(handle)
        raise RuntimeError("another cursor-size host application is already running")
    return int(handle)


def release_mutex(handle: int) -> None:
    if handle:
        ctypes.WinDLL("kernel32").CloseHandle(wintypes.HANDLE(handle))


def save_state(size: int) -> None:
    STATE_PATH.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "original_size": int(size),
        "created": time.strftime("%Y-%m-%d %H:%M:%S"),
        "pid": os.getpid(),
    }
    temporary = STATE_PATH.with_suffix(".tmp")
    temporary.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    temporary.replace(STATE_PATH)


def load_state() -> int | None:
    try:
        payload = json.loads(STATE_PATH.read_text(encoding="utf-8"))
        return int(payload["original_size"])
    except FileNotFoundError:
        return None
    except (ValueError, KeyError, json.JSONDecodeError) as exc:
        raise RuntimeError(f"invalid recovery state: {STATE_PATH}") from exc


def remove_state() -> None:
    STATE_PATH.unlink(missing_ok=True)


def restore_stale_state(controller: CursorSizeController) -> None:
    stale = load_state()
    if stale is None:
        return
    backend = controller.set_size(stale)
    remove_state()
    print(f"[UIAP] 前回の異常終了を検出し、ポインターサイズ {stale} に復旧しました。")
    logging.info("restored stale state size=%s backend=%s", stale, backend)


def device_text(device: dict[str, Any]) -> str:
    return (
        f"product={device.get('product_string')!r}, "
        f"serial={device.get('serial_number')!r}, "
        f"usage_page=0x{int(device.get('usage_page') or 0):04X}, "
        f"usage=0x{int(device.get('usage') or 0):04X}"
    )


def enumerate_devices(serial: str | None = None) -> list[dict[str, Any]]:
    devices = list(hid.enumerate(VID, PID))
    vendor = [d for d in devices if int(d.get("usage_page") or 0) == 0xFF00]
    if vendor:
        devices = vendor
    if serial:
        devices = [d for d in devices if d.get("serial_number") == serial]
    return devices


def open_device(serial: str | None = None):
    devices = enumerate_devices(serial)
    if not devices:
        raise RuntimeError("HID 1209:C004 が見つかりません。make flash とUSB接続を確認してください。")
    if len(devices) > 1:
        details = "\n".join(f"  [{i + 1}] {device_text(d)}" for i, d in enumerate(devices))
        raise RuntimeError(
            "対象HIDが複数あります。1台だけ接続するか --serial を指定してください。\n" + details
        )
    selected = devices[0]
    handle = hid.device()
    handle.open_path(selected["path"])
    handle.set_nonblocking(False)
    return handle, selected


def signed_byte(value: int) -> int:
    return value - 256 if value >= 128 else value


def parse_report(data: list[int]) -> tuple[int, int, int] | None:
    if not data:
        return None
    # Most Windows hidapi builds retain Report ID. Accept stripped-ID data too.
    if len(data) >= 4 and data[0] == REPORT_ID:
        event_type = data[1]
        delta = signed_byte(data[2])
        sequence = data[3]
    elif len(data) >= 3:
        event_type = data[0]
        delta = signed_byte(data[1])
        sequence = data[2]
    else:
        return None
    return event_type, delta, sequence


def size_level(size: int) -> int:
    return ((size - MIN_SIZE) // STEP_SIZE) + 1


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Receive UIAP rotary-encoder HID reports and change the Windows pointer size."
    )
    parser.add_argument("--reverse", action="store_true", help="reverse rotation direction")
    parser.add_argument("--keep", action="store_true", help="keep the last size when the app exits")
    parser.add_argument("--dry-run", action="store_true", help="receive reports without changing Windows")
    parser.add_argument("--list", action="store_true", help="list matching HID devices and exit")
    parser.add_argument("--serial", help="select a USB serial number")
    parser.add_argument(
        "--restore-from-state",
        action="store_true",
        help="restore the saved pre-session cursor size and exit",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    log_path = configure_logging()
    controller = CursorSizeController()

    if args.list:
        devices = enumerate_devices(args.serial)
        if not devices:
            print("[UIAP-A104] HID 1209:C004 は見つかりませんでした。")
            return 1
        for index, device in enumerate(devices, 1):
            print(f"[{index}] {device_text(device)}")
        return 0

    if args.restore_from_state:
        original = load_state()
        if original is None:
            print("[UIAP] 復旧用の保存状態はありません。")
            return 0
        backend = controller.set_size(original)
        remove_state()
        print(f"[UIAP] ポインターサイズを {original} に復旧しました。backend={backend}")
        return 0

    mutex = 0
    device = None
    restore_size: int | None = None
    restored = False

    def restore_on_exit() -> None:
        nonlocal restored
        if restored or restore_size is None or args.keep or args.dry_run:
            return
        restored = True
        try:
            backend = controller.set_size(restore_size)
            remove_state()
            print(f"\n[UIAP] ポインターサイズを起動前の {restore_size} に戻しました。")
            logging.info("restored original size=%s backend=%s", restore_size, backend)
        except Exception:
            logging.exception("failed to restore cursor size")
            print(f"\n[UIAP-A109] 自動復旧に失敗しました。cursorrestore を実行してください。")

    try:
        mutex = acquire_mutex()
        restore_stale_state(controller)
        device, selected = open_device(args.serial)
        current_size = controller.get_size()
        restore_size = current_size
        if not args.dry_run:
            save_state(current_size)
        atexit.register(restore_on_exit)

        print("[UIAP] UIAP RE12000 Cursor Test を開始します。")
        print(f"[UIAP] Encoder: {ENCODER_MODEL} (24 clicks / 24 pulses)")
        print(f"[UIAP] Device: {device_text(selected)}")
        print(f"[UIAP] 起動時サイズ: {current_size} (level {size_level(current_size)}/15)")
        print(f"[UIAP] Log: {log_path}")
        print("[UIAP] エンコーダーを回してください。終了は Ctrl+C です。")
        if args.reverse:
            print("[UIAP] 回転方向を反転しています。")
        if args.dry_run:
            print("[UIAP] dry-run: Windowsの設定は変更しません。")

        last_sequence: int | None = None
        while True:
            try:
                data = list(device.read(8, 750))
            except OSError as exc:
                raise RuntimeError("デバイスが切断されたか、HID読み取りに失敗しました。") from exc

            report = parse_report(data)
            if report is None:
                continue
            event_type, delta, sequence = report
            if event_type != EVENT_ROTATE or delta == 0:
                continue
            if last_sequence == sequence:
                continue
            last_sequence = sequence

            if args.reverse:
                delta = -delta
            direction = "CW" if delta > 0 else "CCW"
            target = max(MIN_SIZE, min(MAX_SIZE, current_size + delta * STEP_SIZE))
            if target == current_size:
                print(f"[UIAP] {direction}: 上限または下限です ({current_size})")
                continue

            backend = "dry-run"
            if not args.dry_run:
                backend = controller.set_size(target)
            current_size = target
            level = size_level(current_size)
            print(f"[UIAP] {direction}: size={current_size}, level={level}/15")
            logging.info(
                "rotation=%s delta=%s sequence=%s size=%s level=%s backend=%s",
                direction,
                delta,
                sequence,
                current_size,
                level,
                backend,
            )

    except KeyboardInterrupt:
        print("\n[UIAP] 終了します。")
        return 0
    except Exception as exc:
        logging.exception("host application failed")
        print(f"[UIAP-A105] {exc}")
        return 1
    finally:
        if device is not None:
            try:
                device.close()
            except Exception:
                pass
        restore_on_exit()
        release_mutex(mutex)
        if args.keep or args.dry_run:
            remove_state()


if __name__ == "__main__":
    raise SystemExit(main())
