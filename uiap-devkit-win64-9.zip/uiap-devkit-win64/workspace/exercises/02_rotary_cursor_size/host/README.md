# Cursor-size host application

このディレクトリは、`02_rotary_cursor_size`演習専用のPC側Pythonプログラムを格納します。

```text
workspace/exercises/02_rotary_cursor_size/host/cursor_size_host.py
```

通常は演習ディレクトリで次を実行します。

```text
make app
```

方向反転:

```text
make app-reverse
```

HIDデバイス一覧:

```text
make list
```

Windows設定を変更せずイベントだけ確認:

```text
cursorapp --dry-run
```

異常終了後の復元:

```text
make restore
```

Devkit全体の診断用Pythonは`scripts/python`へ配置し、このディレクトリへ混在させません。
