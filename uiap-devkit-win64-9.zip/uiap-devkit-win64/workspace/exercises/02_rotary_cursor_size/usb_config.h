#ifndef _USB_CONFIG_H
#define _USB_CONFIG_H

/* EP0 + one interrupt-IN vendor-defined HID endpoint. */
#define ENDPOINTS 2

/* UIAPduino Pro Micro CH32V003 V1.4 software USB pins. */
#define USB_PORT D
#define USB_PIN_DP 3
#define USB_PIN_DM 4
#define USB_PIN_DPU 5

#define RV003USB_OPTIMIZE_FLASH 1
#define RV003USB_EVENT_DEBUGGING 0
#define RV003USB_HANDLE_IN_REQUEST 1
#define RV003USB_OTHER_CONTROL 0
#define RV003USB_HANDLE_USER_DATA 1
#define RV003USB_HID_FEATURES 0

#ifndef __ASSEMBLER__
#ifdef INSTANCE_DESCRIPTORS

#include <stdint.h>

/* Temporary PoC identity. Do not treat 1209:C004 as the final workshop PID. */
static const uint8_t device_descriptor[] = {
    18, 0x01,
    0x10, 0x01,
    0x00, 0x00, 0x00,
    0x08,
    0x09, 0x12,       /* VID 0x1209 */
    0x04, 0xC0,       /* PID 0xC004, temporary RE12000 test value */
    0x05, 0x00,
    1, 2, 3,
    1
};

/*
 * Report ID 1, followed by seven vendor-defined bytes:
 *   byte 1 event type, byte 2 signed delta, byte 3 sequence,
 *   byte 4 raw encoder state, bytes 5-7 reserved/version/flags.
 */
static const uint8_t encoder_hid_desc[] = {
    0x06, 0x00, 0xFF, /* Usage Page (Vendor Defined 0xFF00) */
    0x09, 0x01,       /* Usage 1 */
    0xA1, 0x01,       /* Collection (Application) */
    0x85, 0x01,       /* Report ID 1 */
    0x09, 0x02,       /* Usage 2 */
    0x15, 0x00,       /* Logical Minimum 0 */
    0x26, 0xFF, 0x00, /* Logical Maximum 255 */
    0x75, 0x08,       /* Report Size 8 bits */
    0x95, 0x07,       /* Report Count 7 */
    0x81, 0x02,       /* Input (Data, Variable, Absolute) */
    0xC0
};

/* Configuration + interface + HID + endpoint = 34 bytes. */
static const uint8_t config_descriptor[] = {
    9, 0x02,
    0x22, 0x00,
    0x01,
    0x01,
    0x00,
    0x80,
    0x32,             /* 100 mA */

    9, 0x04,
    0x00,
    0x00,
    0x01,
    0x03,             /* HID */
    0x00,             /* No boot subclass */
    0x00,             /* No boot protocol */
    0x00,

    9, 0x21,
    0x11, 0x01,
    0x00,
    0x01,
    0x22,
    sizeof(encoder_hid_desc), 0x00,

    7, 0x05,
    0x81,             /* EP1 IN */
    0x03,             /* Interrupt */
    0x08, 0x00,
    10                /* 10 ms poll interval */
};

#define STR_MANUFACTURER u"XPfes2026"
#define STR_PRODUCT      u"UIAP RE12000 Cursor Test"
#define STR_SERIAL       u"TEST7-001"

struct usb_string_descriptor_struct {
    uint8_t bLength;
    uint8_t bDescriptorType;
    uint16_t wString[];
};

static const struct usb_string_descriptor_struct string0 __attribute__((section(".rodata"))) = {
    4, 3, {0x0409}
};
static const struct usb_string_descriptor_struct string1 __attribute__((section(".rodata"))) = {
    sizeof(STR_MANUFACTURER), 3, STR_MANUFACTURER
};
static const struct usb_string_descriptor_struct string2 __attribute__((section(".rodata"))) = {
    sizeof(STR_PRODUCT), 3, STR_PRODUCT
};
static const struct usb_string_descriptor_struct string3 __attribute__((section(".rodata"))) = {
    sizeof(STR_SERIAL), 3, STR_SERIAL
};

static const struct descriptor_list_struct {
    uint32_t lIndexValue;
    const uint8_t *addr;
    uint8_t length;
} descriptor_list[] = {
    {0x00000100, device_descriptor, sizeof(device_descriptor)},
    {0x00000200, config_descriptor, sizeof(config_descriptor)},
    {0x00002200, encoder_hid_desc, sizeof(encoder_hid_desc)},
    {0x00000300, (const uint8_t *)&string0, 4},
    {0x04090301, (const uint8_t *)&string1, sizeof(STR_MANUFACTURER)},
    {0x04090302, (const uint8_t *)&string2, sizeof(STR_PRODUCT)},
    {0x04090303, (const uint8_t *)&string3, sizeof(STR_SERIAL)}
};
#define DESCRIPTOR_LIST_ENTRIES (sizeof(descriptor_list) / sizeof(descriptor_list[0]))

#endif
#endif
#endif
