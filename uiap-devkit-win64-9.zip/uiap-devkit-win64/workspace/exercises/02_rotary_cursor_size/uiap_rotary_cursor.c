#include "ch32fun.h"
#include "rv003usb.h"

/*
 * UIAPduino Pro Micro CH32V003 V1.4
 * aitendo RE12000XH1-V02 (24 clicks / 24 pulses)
 *
 * Shaft-side view, signal pins downward:
 *     A   C   B
 *     |   |   |
 *    D8  GND D9
 *
 * Encoder A: D8 / PC6
 * Encoder B: D9 / PC7
 * Encoder C: GND
 * Existing D5 / PC3 momentary switch is intentionally unused.
 * Onboard status LED: D2 / PC0, active high.
 * Software USB: PD3 = D+, PD4 = D-.
 */
#define UIAP_ENCODER_A_PIN PC6
#define UIAP_ENCODER_B_PIN PC7
#define UIAP_LED_PIN       PC0

#define UIAP_REPORT_ID       0x01
#define UIAP_EVENT_NONE      0x00
#define UIAP_EVENT_ROTATE    0x01

/*
 * RE12000XH1-V02 has 24 clicks and 24 pulses per revolution.
 * One click corresponds to one A/B quadrature cycle: four valid edges.
 */
#define UIAP_EDGES_PER_CLICK 4
#define UIAP_LED_PULSE_MS    40

/*
 * Full-step quadrature transition table.
 * With A -> D8, B -> D9 and C -> GND, A leading B produces +1.
 * The host application displays + as CW. Use make app-reverse if the
 * physical mounting direction appears reversed.
 */
static const int8_t quadrature_table[16] = {
     0, -1,  1,  0,
     1,  0,  0, -1,
    -1,  0,  0,  1,
     0,  1, -1,  0
};

static volatile int8_t pending_steps;
static uint8_t sequence_number;
static uint8_t raw_encoder_state;
static uint8_t input_report[8];

static uint8_t read_encoder_state(void)
{
    uint8_t a = funDigitalRead(UIAP_ENCODER_A_PIN) ? 1u : 0u;
    uint8_t b = funDigitalRead(UIAP_ENCODER_B_PIN) ? 1u : 0u;
    return (uint8_t)((a << 1) | b);
}

static void add_pending_step(int8_t step)
{
    int16_t next = (int16_t)pending_steps + step;
    if (next > 127) {
        next = 127;
    }
    else if (next < -127) {
        next = -127;
    }
    pending_steps = (int8_t)next;
}

int main(void)
{
    uint8_t previous_state;
    int8_t transition_accumulator = 0;
    uint8_t led_pulse_remaining = 0;

    SystemInit();
    funGpioInitAll();

    /* Internal pull-ups. Encoder contacts connect A or B to common C/GND. */
    funPinMode(UIAP_ENCODER_A_PIN, GPIO_CFGLR_IN_PUPD);
    funDigitalWrite(UIAP_ENCODER_A_PIN, FUN_HIGH);
    funPinMode(UIAP_ENCODER_B_PIN, GPIO_CFGLR_IN_PUPD);
    funDigitalWrite(UIAP_ENCODER_B_PIN, FUN_HIGH);

    funPinMode(UIAP_LED_PIN, GPIO_Speed_10MHz | GPIO_CNF_OUT_PP);
    funDigitalWrite(UIAP_LED_PIN, FUN_LOW);

    previous_state = read_encoder_state();
    raw_encoder_state = previous_state;

    /* Give Windows time to observe disconnect after leaving the bootloader. */
    Delay_Ms(100);
    usb_setup();

    while (1) {
        uint8_t current_state = read_encoder_state();
        if (current_state != previous_state) {
            uint8_t index = (uint8_t)((previous_state << 2) | current_state);
            int8_t transition = quadrature_table[index];
            previous_state = current_state;
            raw_encoder_state = current_state;

            if (transition == 0) {
                /* Invalid two-bit jump or contact bounce: discard partial click. */
                transition_accumulator = 0;
            }
            else {
                transition_accumulator += transition;
                if (transition_accumulator >= UIAP_EDGES_PER_CLICK) {
                    add_pending_step(1);
                    transition_accumulator = 0;
                    led_pulse_remaining = UIAP_LED_PULSE_MS;
                }
                else if (transition_accumulator <= -UIAP_EDGES_PER_CLICK) {
                    add_pending_step(-1);
                    transition_accumulator = 0;
                    led_pulse_remaining = UIAP_LED_PULSE_MS;
                }
            }
        }

        if (led_pulse_remaining > 0) {
            funDigitalWrite(UIAP_LED_PIN, FUN_HIGH);
            led_pulse_remaining--;
        }
        else {
            funDigitalWrite(UIAP_LED_PIN, FUN_LOW);
        }

        Delay_Ms(1);
    }
}

void usb_handle_user_data(
    struct usb_endpoint *e,
    int current_endpoint,
    uint8_t *data,
    int len,
    struct rv003usb_internal *ist)
{
    (void)e;
    (void)current_endpoint;
    (void)data;
    (void)len;
    (void)ist;
}

void usb_handle_user_in_request(
    struct usb_endpoint *e,
    uint8_t *scratchpad,
    int endp,
    uint32_t sendtok,
    struct rv003usb_internal *ist)
{
    (void)e;
    (void)scratchpad;
    (void)ist;

    if (endp == 1) {
        int8_t delta = pending_steps;
        pending_steps = 0;

        input_report[0] = UIAP_REPORT_ID;
        input_report[1] = (delta == 0) ? UIAP_EVENT_NONE : UIAP_EVENT_ROTATE;
        input_report[2] = (uint8_t)delta;
        input_report[3] = sequence_number;
        input_report[4] = raw_encoder_state;
        input_report[5] = 24; /* clicks per revolution */
        input_report[6] = 7;  /* firmware test version */
        input_report[7] = 0;

        if (delta != 0) {
            sequence_number++;
        }

        usb_send_data(input_report, sizeof(input_report), 0, sendtok);
    }
    else {
        usb_send_empty(sendtok);
    }
}
