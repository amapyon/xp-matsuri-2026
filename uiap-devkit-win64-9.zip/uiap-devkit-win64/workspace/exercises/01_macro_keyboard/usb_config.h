#ifndef _USB_CONFIG_H
#define _USB_CONFIG_H

/* EP0 + one interrupt-IN keyboard endpoint. */
#define ENDPOINTS 2

/* UIAPduino Pro Micro CH32V003 V1.4 software USB pins. */
#define USB_PORT D
#define USB_PIN_DP 3
#define USB_PIN_DM 4
#define USB_PIN_DPU 5

#define RV003USB_OPTIMIZE_FLASH 1
#define RV003USB_EVENT_DEBUGGING 0
#define RV003USB_HANDLE_IN_REQUEST 1
#define RV003USB_OTHER_CONTROL 0
#define RV003USB_HANDLE_USER_DATA 1
#define RV003USB_HID_FEATURES 0

#ifndef __ASSEMBLER__
#ifdef INSTANCE_DESCRIPTORS

#include <stdint.h>

/* Temporary PoC identity. Do not treat 1209:C003 as the final workshop PID. */
static const uint8_t device_descriptor[] = {
    18, 0x01,
    0x10, 0x01,
    0x00, 0x00, 0x00,
    0x08,
    0x09, 0x12,       /* VID 0x1209 */
    0x03, 0xC0,       /* PID 0xC003, temporary test value */
    0x03, 0x00,
    1, 2, 3,
    1
};

/* Standard 8-byte boot-keyboard report descriptor. */
static const uint8_t keyboard_hid_desc[] = {
    0x05, 0x01,       /* Usage Page (Generic Desktop) */
    0x09, 0x06,       /* Usage (Keyboard) */
    0xA1, 0x01,       /* Collection (Application) */
    0x05, 0x07,       /* Usage Page (Keyboard) */
    0x19, 0xE0,       /* Usage Minimum (Left Control) */
    0x29, 0xE7,       /* Usage Maximum (Right GUI) */
    0x15, 0x00,
    0x25, 0x01,
    0x75, 0x01,
    0x95, 0x08,
    0x81, 0x02,       /* Input: modifier bitmap */
    0x95, 0x01,
    0x75, 0x08,
    0x81, 0x01,       /* Input: reserved byte */
    0x95, 0x05,
    0x75, 0x01,
    0x05, 0x08,       /* Usage Page (LEDs) */
    0x19, 0x01,
    0x29, 0x05,
    0x91, 0x02,       /* Output: lock LEDs */
    0x95, 0x01,
    0x75, 0x03,
    0x91, 0x01,       /* Output: padding */
    0x95, 0x06,
    0x75, 0x08,
    0x15, 0x00,
    0x25, 0x65,
    0x05, 0x07,
    0x19, 0x00,
    0x29, 0x65,
    0x81, 0x00,       /* Input: six key codes */
    0xC0
};

/* Configuration + interface + HID + endpoint = 34 bytes. */
static const uint8_t config_descriptor[] = {
    9, 0x02,
    0x22, 0x00,
    0x01,
    0x01,
    0x00,
    0x80,
    0x32,             /* 100 mA */

    9, 0x04,
    0x00,
    0x00,
    0x01,
    0x03,             /* HID */
    0x01,             /* Boot Interface Subclass */
    0x01,             /* Keyboard protocol */
    0x00,

    9, 0x21,
    0x11, 0x01,
    0x00,
    0x01,
    0x22,
    sizeof(keyboard_hid_desc), 0x00,

    7, 0x05,
    0x81,             /* EP1 IN */
    0x03,             /* Interrupt */
    0x08, 0x00,
    10                /* 10 ms poll interval */
};

#define STR_MANUFACTURER u"XPfes2026"
#define STR_PRODUCT      u"UIAP Macro Keyboard Test"
#define STR_SERIAL       u"TEST3-001"

struct usb_string_descriptor_struct {
    uint8_t bLength;
    uint8_t bDescriptorType;
    uint16_t wString[];
};

static const struct usb_string_descriptor_struct string0 __attribute__((section(".rodata"))) = {
    4, 3, {0x0409}
};
static const struct usb_string_descriptor_struct string1 __attribute__((section(".rodata"))) = {
    sizeof(STR_MANUFACTURER), 3, STR_MANUFACTURER
};
static const struct usb_string_descriptor_struct string2 __attribute__((section(".rodata"))) = {
    sizeof(STR_PRODUCT), 3, STR_PRODUCT
};
static const struct usb_string_descriptor_struct string3 __attribute__((section(".rodata"))) = {
    sizeof(STR_SERIAL), 3, STR_SERIAL
};

static const struct descriptor_list_struct {
    uint32_t lIndexValue;
    const uint8_t *addr;
    uint8_t length;
} descriptor_list[] = {
    {0x00000100, device_descriptor, sizeof(device_descriptor)},
    {0x00000200, config_descriptor, sizeof(config_descriptor)},
    {0x00002200, keyboard_hid_desc, sizeof(keyboard_hid_desc)},
    {0x00000300, (const uint8_t *)&string0, 4},
    {0x04090301, (const uint8_t *)&string1, sizeof(STR_MANUFACTURER)},
    {0x04090302, (const uint8_t *)&string2, sizeof(STR_PRODUCT)},
    {0x04090303, (const uint8_t *)&string3, sizeof(STR_SERIAL)}
};
#define DESCRIPTOR_LIST_ENTRIES (sizeof(descriptor_list) / sizeof(descriptor_list[0]))

#endif
#endif
#endif
