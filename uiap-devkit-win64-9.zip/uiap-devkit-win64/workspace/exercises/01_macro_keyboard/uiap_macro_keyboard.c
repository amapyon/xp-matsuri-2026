#include "ch32fun.h"
#include "rv003usb.h"
#include "tinyusb_hid.h"

/*
 * UIAPduino Pro Micro CH32V003 V1.4
 *   Momentary switch: D5 / PC3 to GND
 *   Onboard status LED: D2 / PC0, active high
 *   Software USB: PD3 = D+, PD4 = D-
 */
#define UIAP_SWITCH_PIN PC3
#define UIAP_LED_PIN    PC0

#define KEY_DOWN_POLLS  3
#define KEY_UP_POLLS    2

struct macro_key {
    uint8_t modifier;
    uint8_t keycode;
};

static const struct macro_key macro_sequence[] = {
    { KEYBOARD_MODIFIER_LEFTSHIFT, HID_KEY_A },
    { 0,                           HID_KEY_B },
    { KEYBOARD_MODIFIER_LEFTSHIFT, HID_KEY_C },
    { 0,                           HID_KEY_D },
    { KEYBOARD_MODIFIER_LEFTSHIFT, HID_KEY_E }
};

static volatile uint8_t macro_requested;
static volatile uint8_t macro_active;
static uint8_t macro_index;
static uint8_t key_is_down;
static uint8_t polls_remaining;
static uint8_t keyboard_report[8];

static void clear_keyboard_report(void)
{
    for (uint8_t i = 0; i < sizeof(keyboard_report); i++) {
        keyboard_report[i] = 0;
    }
}

static void load_macro_key(uint8_t index)
{
    clear_keyboard_report();
    keyboard_report[0] = macro_sequence[index].modifier;
    keyboard_report[2] = macro_sequence[index].keycode;
}

static void start_macro_if_requested(void)
{
    if (macro_active || !macro_requested) {
        return;
    }

    macro_requested = 0;
    macro_active = 1;
    macro_index = 0;
    key_is_down = 1;
    polls_remaining = KEY_DOWN_POLLS;
    load_macro_key(macro_index);
}

static void advance_macro_after_report(void)
{
    if (!macro_active) {
        return;
    }

    if (polls_remaining > 0) {
        polls_remaining--;
    }
    if (polls_remaining != 0) {
        return;
    }

    if (key_is_down) {
        clear_keyboard_report();
        key_is_down = 0;
        polls_remaining = KEY_UP_POLLS;
        return;
    }

    macro_index++;
    if (macro_index >= (sizeof(macro_sequence) / sizeof(macro_sequence[0]))) {
        clear_keyboard_report();
        macro_active = 0;
        return;
    }

    load_macro_key(macro_index);
    key_is_down = 1;
    polls_remaining = KEY_DOWN_POLLS;
}

int main(void)
{
    uint8_t button_history = 0xFF;
    uint8_t button_pressed = 0;

    SystemInit();
    funGpioInitAll();

    /* Internal pull-up: released=HIGH, pressed=LOW. */
    funPinMode(UIAP_SWITCH_PIN, GPIO_CFGLR_IN_PUPD);
    funDigitalWrite(UIAP_SWITCH_PIN, FUN_HIGH);

    funPinMode(UIAP_LED_PIN, GPIO_Speed_10MHz | GPIO_CNF_OUT_PP);
    funDigitalWrite(UIAP_LED_PIN, FUN_LOW);

    clear_keyboard_report();

    /* Give the host time to observe disconnect after leaving the bootloader. */
    Delay_Ms(100);
    usb_setup();

    while (1) {
        button_history = (uint8_t)((button_history << 1) |
            (funDigitalRead(UIAP_SWITCH_PIN) ? 1u : 0u));

        if ((button_history == 0x00) && !button_pressed) {
            button_pressed = 1;
            if (!macro_active) {
                macro_requested = 1;
            }
        }
        else if ((button_history == 0xFF) && button_pressed) {
            button_pressed = 0;
        }

        funDigitalWrite(UIAP_LED_PIN, macro_active ? FUN_HIGH : FUN_LOW);
        Delay_Ms(1);
    }
}

void usb_handle_user_data(
    struct usb_endpoint *e,
    int current_endpoint,
    uint8_t *data,
    int len,
    struct rv003usb_internal *ist)
{
    (void)e;
    (void)current_endpoint;
    (void)data;
    (void)len;
    (void)ist;
}

void usb_handle_user_in_request(
    struct usb_endpoint *e,
    uint8_t *scratchpad,
    int endp,
    uint32_t sendtok,
    struct rv003usb_internal *ist)
{
    (void)e;
    (void)scratchpad;
    (void)ist;

    if (endp == 1) {
        start_macro_if_requested();
        usb_send_data(keyboard_report, sizeof(keyboard_report), 0, sendtok);
        advance_macro_after_report();
    }
    else {
        usb_send_empty(sendtok);
    }
}
