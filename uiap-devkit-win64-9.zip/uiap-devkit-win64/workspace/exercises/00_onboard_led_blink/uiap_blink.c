#include "ch32fun.h"

/* UIAPduino Pro Micro CH32V003 V1.4 onboard LED: PC0, active high. */
#define UIAP_LED_PIN PC0

int main(void)
{
    SystemInit();
    funGpioInitAll();
    funPinMode(UIAP_LED_PIN, GPIO_Speed_10MHz | GPIO_CNF_OUT_PP);

    while (1)
    {
        funDigitalWrite(UIAP_LED_PIN, FUN_HIGH);
        Delay_Ms(200);

        funDigitalWrite(UIAP_LED_PIN, FUN_LOW);
        Delay_Ms(800);
    }
}
