# 00 Onboard LED Blink

## 目的

UIAPduino Pro Micro CH32V003 V1.4の基板上LEDを、PC0から制御して点滅させます。

## 使用部品

- UIAPduino Pro Micro CH32V003 V1.4 1台
- データ通信対応USBケーブル 1本
- 外付け部品なし

## ビルド

```text
make
```

## 書き込み

```text
make flash
```

## 成功条件

基板上LEDが、0.2秒点灯、0.8秒消灯を繰り返します。

## 安全上の注意

最初の書き込み確認では、外付け回路をすべて外してください。UIAPduinoは1台だけ接続してください。
